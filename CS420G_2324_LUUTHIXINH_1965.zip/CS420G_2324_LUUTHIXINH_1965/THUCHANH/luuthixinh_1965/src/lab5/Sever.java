/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5;

/**
 *
 * @author ADMIN
 */
import java.net.*;
public class Sever {
     public static void main(String[] args) {
        try {
            // 1. Tạo socket UDP trên cổng 1234
            DatagramSocket serverSocket = new DatagramSocket(1234);
            byte[] receiveData = new byte[1024];
            byte[] sendData;

            System.out.println("Server đang đợi dữ liệu từ Client...");

            // 2. Chờ nhận dữ liệu từ Client
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);
            String receivedString = new String(receivePacket.getData()).trim();
            System.out.println("Nhận dữ liệu: " + receivedString);

            // 3. Tách 3 số a, b, c từ chuỗi nhận được
            String[] parts = receivedString.split(" ");
            double a = Double.parseDouble(parts[0]);
            double b = Double.parseDouble(parts[1]);
            double c = Double.parseDouble(parts[2]);

            // 4. Kiểm tra xem 3 số đó có tạo thành tam giác không
            String result;
            if (isTriangle(a, b, c)) {
                result = "3 cạnh này tạo thành một tam giác " + getTriangleType(a, b, c);
            } else {
                result = "3 cạnh này không tạo thành một tam giác.";
            }

            // 5. Gửi kết quả về Client
            InetAddress clientAddress = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();
            sendData = result.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);

            // 6. Đóng socket
            serverSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Hàm kiểm tra 3 số có tạo thành tam giác không
    public static boolean isTriangle(double a, double b, double c) {
        return a + b > c && a + c > b && b + c > a;
    }

    // Hàm xác định loại tam giác
    public static String getTriangleType(double a, double b, double c) {
        if (a == b && b == c) {
            return "đều.";
        } else if (a == b || b == c || a == c) {
            return "cân.";
        } else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a) {
            return "vuông.";
        } else {
            return "thường.";
        }
    }
}
