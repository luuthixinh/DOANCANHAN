/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5;

/**
 *
 * @author ADMIN
 */
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Client extends JFrame implements ActionListener {
    private JTextField txtA, txtB, txtC;
    private JButton btnSend;
    private JTextArea resultArea;

    public Client() {
        // 1. Tạo giao diện
        setTitle("Kiểm tra tam giác");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        // 2. Tạo các thành phần giao diện
        add(new JLabel("Nhập cạnh a: "));
        txtA = new JTextField();
        add(txtA);

        add(new JLabel("Nhập cạnh b: "));
        txtB = new JTextField();
        add(txtB);

        add(new JLabel("Nhập cạnh c: "));
        txtC = new JTextField();
        add(txtC);

        btnSend = new JButton("Gửi đến Server");
        add(btnSend);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea));

        // 3. Gắn sự kiện cho nút gửi
        btnSend.addActionListener(this);

        // 4. Hiển thị cửa sổ
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // 5. Tạo socket UDP
            DatagramSocket clientSocket = new DatagramSocket();

            // 6. Lấy các giá trị từ giao diện
            double a = Double.parseDouble(txtA.getText());
            double b = Double.parseDouble(txtB.getText());
            double c = Double.parseDouble(txtC.getText());

            // 7. Chuẩn bị dữ liệu để gửi
            String dataToSend = a + " " + b + " " + c;
            byte[] sendData = dataToSend.getBytes();

            // 8. Gửi dữ liệu đến Server
            InetAddress serverAddress = InetAddress.getByName("localhost");
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, 1234);
            clientSocket.send(sendPacket);

            // 9. Nhận kết quả từ Server
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            clientSocket.receive(receivePacket);
            String result = new String(receivePacket.getData()).trim();

            // 10. Hiển thị kết quả trong giao diện
            resultArea.setText(result);

            // 11. Đóng kết nối
            clientSocket.close();
        } catch (Exception ex) {
            resultArea.setText("Lỗi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Client();
    }
}
