/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2;

/**
 *
 * @author ADMIN
 */
import java.io.*;
import java.net.*;
import java.util.Scanner;
public class Client {
    public static void main(String[] args) {
        try {
            // Kết nối tới server tại địa chỉ localhost và cổng 1234
            Socket socket = new Socket("localhost", 1234);

            // Tạo luồng gửi và nhận dữ liệu
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Nhập chuỗi ký tự từ bàn phím
            Scanner sc = new Scanner(System.in);
            System.out.print("Nhập chuỗi ký tự: ");
            String input = sc.nextLine();

            // Gửi chuỗi ký tự tới server
            out.println(input);

            // Nhận kết quả từ server và hiển thị
            String response;
            while ((response = in.readLine()) != null) {
                System.out.println(response);
            }

            // Đóng kết nối
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
