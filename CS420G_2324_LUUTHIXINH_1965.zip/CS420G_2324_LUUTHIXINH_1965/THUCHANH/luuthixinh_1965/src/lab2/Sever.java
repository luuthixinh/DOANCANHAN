/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2;

/**
 *
 * @author ADMIN
 */
import java.io.*;
import java.net.*;
import java.util.HashMap;
public class Sever {
    public static void main(String[] args) {
        try {
         
            ServerSocket server = new ServerSocket(1234);
            System.out.println("Server đang đợi kết nối...");

            // Chấp nhận kết nối từ Client
            Socket socket = server.accept();
            System.out.println("Client đã kết nối!");

            // Nhận dữ liệu từ client
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // Gửi dữ liệu đến client
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            // Đọc chuỗi ký tự từ Client
            String input = in.readLine();
            System.out.println("Nhận từ Client: " + input);

            // Tính số lượng ký tự, chữ số, chữ cái
            int totalChars = input.length();
            int digitCount = 0;
            int letterCount = 0;

            // Đếm số lượng trùng lặp
            HashMap<Character, Integer> frequencyMap = new HashMap<>();

            for (char c : input.toCharArray()) {
                if (Character.isDigit(c)) {
                    digitCount++;
                } else if (Character.isLetter(c)) {
                    letterCount++;
                }

                // Đếm số lần xuất hiện của từng ký tự
                frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
            }

            // Tạo chuỗi ký tự trùng lặp
            StringBuilder duplicateChars = new StringBuilder();
            for (char c : frequencyMap.keySet()) {
                if (frequencyMap.get(c) > 1) {
                    duplicateChars.append(c).append(" (").append(frequencyMap.get(c)).append(" lần), ");
                }
            }

            if (duplicateChars.length() > 0) {
                // Xóa dấu phẩy cuối cùng
                duplicateChars.setLength(duplicateChars.length() - 2);
            } else {
                duplicateChars.append("Không có ký tự trùng lặp");
            }

            // Tạo chuỗi đảo ngược
            String reversedString = new StringBuilder(input).reverse().toString();

            // Gửi kết quả lại cho client
            out.println("Số lượng ký tự: " + totalChars);
            out.println("Số lượng chữ số: " + digitCount);
            out.println("Số lượng chữ cái: " + letterCount);
            out.println("Số lượng ký tự trùng lặp: " + duplicateChars.toString());
            out.println("Chuỗi đảo ngược: " + reversedString);

            // Đóng kết nối
            socket.close();
            server.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
