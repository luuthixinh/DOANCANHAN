/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;

import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Client extends JFrame implements ActionListener {
     private JTextField txtA, txtB, txtC;
    private JButton btnSend;
    private JTextArea resultArea;

    public Client() {
        // 1. Tạo giao diện
        setTitle("Giải phương trình bậc 2");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        // 2. Tạo các thành phần giao diện
        add(new JLabel("Nhập a: "));
        txtA = new JTextField();
        add(txtA);

        add(new JLabel("Nhập b: "));
        txtB = new JTextField();
        add(txtB);

        add(new JLabel("Nhập c: "));
        txtC = new JTextField();
        add(txtC);

        btnSend = new JButton("Gửi đến Server");
        add(btnSend);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea));

        // 3. Gắn sự kiện cho nút gửi
        btnSend.addActionListener(this);

        // 4. Hiển thị cửa sổ
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
         
            Socket socket = new Socket("localhost", 1234);

            // 6. Tạo luồng gửi và nhận dữ 
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            // 7. Lấy các hệ số a, b, c từ giao diện và gửi cho server
            double a = Double.parseDouble(txtA.getText());
            double b = Double.parseDouble(txtB.getText());
            double c = Double.parseDouble(txtC.getText());

            out.writeDouble(a);
            out.writeDouble(b);
            out.writeDouble(c);

            // 8. Nhận kết quả từ server và hiển thị
            String result = in.readUTF();
            resultArea.setText(result);

            // 9. Đóng kết nối
            socket.close();
        } catch (IOException | NumberFormatException ex) {
            resultArea.setText("Lỗi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Client();
    }
}
