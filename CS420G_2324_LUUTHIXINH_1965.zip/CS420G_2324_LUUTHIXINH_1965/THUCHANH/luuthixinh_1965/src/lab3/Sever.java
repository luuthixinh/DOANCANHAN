/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3;
import java.io.*;
import java.net.*;
public class Sever {
     public static void main(String[] args) {
        try {
            // 1. Tạo server socket trên cổng 1234
            ServerSocket server = new ServerSocket(1234);
            System.out.println("Server đang đợi kết nối...");

            // 2. Chấp nhận kết nối từ Client
            Socket socket = server.accept();
            System.out.println("Client đã kết nối!");

            // 3. Nhận dữ liệu từ client
            DataInputStream in = new DataInputStream(socket.getInputStream());
            // 4. Gửi dữ liệu đến client
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            // 5. Đọc các hệ số a, b, c từ Client
            double a = in.readDouble();
            double b = in.readDouble();
            double c = in.readDouble();
            System.out.println("Nhận từ Client: a=" + a + ", b=" + b + ", c=" + c);
            double delta = b * b - 4 * a * c;
            String result;
            if (delta > 0) {
                double x1 = (-b + Math.sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.sqrt(delta)) / (2 * a);
                result = "Phương trình có 2 nghiệm: x1 = " + x1 + ", x2 = " + x2;
            } else if (delta == 0) {
                double x = -b / (2 * a);
                result = "Phương trình có nghiệm kép: x = " + x;
            } else {
                result = "Phương trình vô nghiệm.";
            }
            out.writeUTF(result);
            socket.close();
            server.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
