/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

/**
 *
 * @author ADMIN
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.rmi.Naming;
public class Client extends JFrame implements ActionListener{
     private JTextField txtA, txtB, txtC;
    private JButton btnSend;
    private JTextArea resultArea;
    private TamGiac tamGiac;

    public Client() {
        
        try {
            tamGiac = (TamGiac) Naming.lookup("rmi://localhost/TamGiac");
        } catch (Exception e) {
            e.printStackTrace();
        }

      
        setTitle("Kiểm tra loại tam giác");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        
        add(new JLabel("Nhập cạnh a: "));
        txtA = new JTextField();
        add(txtA);

        add(new JLabel("Nhập cạnh b: "));
        txtB = new JTextField();
        add(txtB);

        add(new JLabel("Nhập cạnh c: "));
        txtC = new JTextField();
        add(txtC);

        btnSend = new JButton("Kiểm tra tam giác");
        add(btnSend);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea));

        
        btnSend.addActionListener(this);

        // 5. Hiển thị cửa sổ
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // 6. Lấy các giá trị nhập từ giao diện
            double a = Double.parseDouble(txtA.getText());
            double b = Double.parseDouble(txtB.getText());
            double c = Double.parseDouble(txtC.getText());

           
            String result = tamGiac.kiemTraTamGiac(a, b, c);

            // 8. Hiển thị kết quả
            resultArea.setText(result);
        } catch (Exception ex) {
            resultArea.setText("Lỗi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Client();
    }
}
