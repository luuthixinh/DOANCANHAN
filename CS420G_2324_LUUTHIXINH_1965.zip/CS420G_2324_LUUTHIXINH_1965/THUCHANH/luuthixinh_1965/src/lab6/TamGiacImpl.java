/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

/**
 *
 * @author ADMIN
 */
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
public class TamGiacImpl extends UnicastRemoteObject implements TamGiac {
     protected TamGiacImpl() throws RemoteException {
        super();
    }

    @Override
    public String kiemTraTamGiac(double a, double b, double c) throws RemoteException {
        if (!isTriangle(a, b, c)) {
            return "Không phải là tam giác.";
        } else if (a == b && b == c) {
            return "Tam giác đều.";
        } else if (a == b || b == c || a == c) {
            if (isRightTriangle(a, b, c)) {
                return "Tam giác vuông cân.";
            }
            return "Tam giác cân.";
        } else if (isRightTriangle(a, b, c)) {
            return "Tam giác vuông.";
        } else {
            return "Tam giác thường.";
        }
    }

    // Kiểm tra xem 3 cạnh có tạo thành tam giác không
    private boolean isTriangle(double a, double b, double c) {
        return a + b > c && a + c > b && b + c > a;
    }

    // Kiểm tra tam giác vuông
    private boolean isRightTriangle(double a, double b, double c) {
        return (a * a + b * b == c * c) || (a * a + c * c == b * b) || (b * b + c * c == a * a);
    }
}
