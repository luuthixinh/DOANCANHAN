/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

/**
 *
 * @author ADMIN
 */
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
public class Sever {
    public static void main(String[] args) {
        try {
            // Tạo đối tượng thực thi RMI
            TamGiacImpl tamGiac = new TamGiacImpl();

            // Đăng ký RMI registry trên cổng 1099
            LocateRegistry.createRegistry(1099);

            // Bind đối tượng với tên "TamGiac"
            Naming.rebind("rmi://localhost/TamGiac", tamGiac);

            System.out.println("Server đã sẵn sàng.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
