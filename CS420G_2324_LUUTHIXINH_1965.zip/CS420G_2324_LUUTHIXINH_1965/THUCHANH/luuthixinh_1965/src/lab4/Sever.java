/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4;
import java.io.*;
import java.net.*;
public class Sever {
    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(1234);
            System.out.println("Server đang đợi kết nối...");
            Socket socket = server.accept();
            System.out.println("Client đã kết nối!");
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            int number = in.readInt();
            System.out.println("Số nhận từ Client: " + number);
            boolean isFibonacci = isFibonacci(number);
            if (isFibonacci) {
                out.writeUTF(number + " là số Fibonacci.");
            } else {
                out.writeUTF(number + " không phải là số Fibonacci.");
            }
            socket.close();
            server.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static boolean isFibonacci(int n) {
        return isPerfectSquare(5 * n * n + 4) || isPerfectSquare(5 * n * n - 4);
    }
    public static boolean isPerfectSquare(int x) {
        int s = (int) Math.sqrt(x);
        return s * s == x;
    }
}
