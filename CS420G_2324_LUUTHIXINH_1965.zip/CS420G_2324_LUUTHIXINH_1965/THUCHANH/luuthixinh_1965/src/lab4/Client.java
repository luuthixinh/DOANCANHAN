/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4;

/**
 *
 * @author ADMIN
 */
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Client extends JFrame implements ActionListener {
     private JTextField txtNumber;
    private JButton btnSend;
    private JTextArea resultArea;

    public Client() {
        // 1. Tạo giao diện
        setTitle("Kiểm tra số Fibonacci");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        // 2. Tạo các thành phần giao diện
        add(new JLabel("Nhập số cần kiểm tra: "));
        txtNumber = new JTextField();
        add(txtNumber);

        btnSend = new JButton("Gửi đến Server");
        add(btnSend);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea));

        // 3. Gắn sự kiện cho nút gửi
        btnSend.addActionListener(this);

        // 4. Hiển thị cửa sổ
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // 5. Kết nối tới server tại địa chỉ localhost và cổng 1234
            Socket socket = new Socket("localhost", 1234);

            // 6. Tạo luồng gửi và nhận dữ liệu
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());
             int number =  Integer.parseInt(txtNumber.getText());
            out.writeInt(number);
              String result = in.readUTF();
            resultArea.setText(result);

            // 9. Đóng kết nối
            socket.close();
        } catch (IOException | NumberFormatException ex) {
            resultArea.setText("Lỗi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Client();
    }
}
